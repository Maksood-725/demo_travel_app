// Home.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Home.css'; // Common CSS file

const Home = () => {
    const [places, setPlaces] = useState([]);
    const [categories, setCategories] = useState([]);

    useEffect(() => {
        fetch("https://traveller.talrop.works/api/v1/places/")
            .then(response => response.json())
            .then(data => {
                if (data.StatusCode === 6000) setPlaces(data.data);
            })
            .catch(error => console.error("Failed to fetch places.", error));

        fetch("https://traveller.talrop.works/api/v1/places/categories/")
            .then(response => response.json())
            .then(data => {
                if (data.StatusCode === 6000) setCategories(data.data);
            })
            .catch(error => console.error("Failed to fetch categories.", error));
    }, []);

    return (
        <div className="home">
            <header className="header">
                <div className="left">
                    <h1><img src="/path/to/logo.svg" alt="Logo" /></h1>
                </div>
                <div className="right">
                    <button className="login-btn">Login</button>
                </div>
            </header>
            <div className="head">
                <h2>Welcome to the Travel App</h2>
                <p>Explore the world around you</p>
                <ul>
                    {categories.map(category => (
                        <li key={category.id}>
                            <a href="#">
                                <img className="rest" src={category.image} alt={category.name} />
                                <span>{category.name}</span>
                            </a>
                        </li>
                    ))}
                </ul>
            </div>
            <div className="items">
                {places.map(place => (
                    <div className="item" key={place.id}>
                        <Link to={`/place/${place.id}`}>
                            <div className="top">
                                <img src={place.image} alt={place.name} />
                            </div>
                            <div className="middle"><h3>{place.name}</h3></div>
                            <div className="bottom">
                                <img src="/path/to/location-icon.svg" alt="Location" />
                                <span>{place.location}</span>
                            </div>
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Home;