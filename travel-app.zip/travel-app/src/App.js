import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './components/Header';
import CategoryList from './components/CategoryList';
import PlacesList from './components/PlacesList';
import './App.css';
import Home from './Home';
import PlaceDetails from './PlaceDetails';
import './App.css'; // Combined CSS for consistency


function App() {
    const [categories, setCategories] = useState([]);
    const [places, setPlaces] = useState([]);

    useEffect(() => {
        axios.get('https://traveller.talrop.works/api/v1/places/categories/')
            .then(response => {
                if (response.data.StatusCode === 6000) {
                    setCategories(response.data.data);
                }
            })
            .catch(() => console.error("Failed to fetch categories."));
        
        axios.get('https://traveller.talrop.works/api/v1/places/')
            .then(response => {
                if (response.data.StatusCode === 6000) {
                    setPlaces(response.data.data);
                }
            })
            .catch(() => console.error("Failed to fetch places."));
    }, []);

    return (
        <div className="wrapper">
            <Header />
            <div className="head">
                <h2>Welcome John Doe</h2>
                <p>Explore the world around you</p>
                <CategoryList categories={categories} />
            </div>
            <PlacesList places={places} />
        </div>
    );
}


export default App;
