import React from 'react';
import  './PlacesList.css';
import place from './images/place.svg'

function PlacesList({ places }) {
    return (
        <div className="items">
            {places.map((place, index) => (
                <div className="item" key={index}>
                    <a href="#">
                        <div className="top">
                            <img src={place.image} alt={place.name} />
                        </div>
                        <div className="middle">
                            <h3>{place.name}</h3>
                        </div>
                        <div className="bottom">
                            <img src={place} alt="Location" />
                            <span>{place.location}</span>
                        </div>
                    </a>
                </div>
            ))}
        </div>
    );
}

export default PlacesList;