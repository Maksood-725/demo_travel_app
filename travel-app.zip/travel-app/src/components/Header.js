import React from 'react';
import './Header.css';
import Logo from './images/logo.svg'
import search from './images/search.svg'

function Header() {
    return (
        <header>
            <div className="left">
                <h1>
                    <a href="#">
                        <img src={Logo} alt="Logo" />
                    </a>
                </h1>
            </div>
            <div className="right">
                <form>
                    <img src={search} alt="Search Icon" />
                    <input type="search" placeholder="Search.." />
                </form>
            </div>
        </header>
    );
}

export default Header;