// PlaceDetails.js
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './PlaceDetails.css'; // Common CSS file

const PlaceDetails = () => {
    const { id } = useParams();
    const [place, setPlace] = useState(null);

    useEffect(() => {
        fetch(`https://traveller.talrop.works/api/v1/places/${id}`)
            .then(response => response.json())
            .then(data => setPlace(data))
            .catch(error => console.error('Error fetching place details:', error));
    }, [id]);

    if (!place) {
        return <div>Loading...</div>;
    }

    return (
        <div className="place-details">
            <header className="header">
                <div className="left">
                    <h1><img src="/path/to/logo.svg" alt="Logo" /></h1>
                </div>
                <div className="right">
                    <button className="login-btn">Login</button>
                </div>
            </header>

            <section className="place-info">
                <div className="left-section">
                    <h2>{place.name}</h2>
                    <p>Category: {place.category} | Location: {place.location}</p>
                    <img src={place.imagePath} alt={place.name} />
                </div>
                <div className="right-section">
                    <div className="image-grid">
                        {place.galleryImages.map((imgPath, index) => (
                            <img
                                key={index}
                                src={imgPath}
                                alt={`Gallery ${index + 1}`}
                                onClick={() => window.location.href = `/gallery/${index}`}
                            />
                        ))}
                    </div>
                </div>
            </section>

            <section className="details-section">
                <h3>Place Details</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...</p>
            </section>
        </div>
    );
};

export default PlaceDetails;