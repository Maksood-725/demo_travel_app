import { Link } from 'react-router-dom';

function PlacesList({ places }) {
    return (
        <div className="places-list">
            {places.map(place => (
                <div key={place.id} className="place-item">
                    <Link to={`/place/${place.id}`}>
                        <h3>{place.name}</h3>
                        <p>{place.location}</p>
                    </Link>
                </div>
            ))}
        </div>
    );
}

export default PlacesList;